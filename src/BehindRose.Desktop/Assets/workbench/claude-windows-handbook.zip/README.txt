Claude Windows 详细操作手册
核对日期：2026-10-24

先解压完整工具包，再双击 claude-guide.html 开始阅读。
HTML 已嵌入全部 8 张配图，无需联网加载图片。
claude-guide.md 是可继续编辑的文稿，图片保存在 images 文件夹。

操作主线：Windows 原生 PowerShell + Clash Verge 或同类 HTTP 代理 + 官方 Claude Code。
从文章开头的注意事项开始，首次配置按第 02 到第 08 节进行。
已正常使用的环境从第 09 节开始；明确封禁从第 12 节开始。

scripts 文件夹包含：
1. Test-ClaudeNetwork.ps1：检查本地端口、出口 IP 和网页 HTTP 响应。
2. Launch-Claude.ps1：为本次 Claude 进程设置代理，结束后恢复原进程环境和目录。
3. Backup-ClaudeLocal.ps1：复制本地 Claude 配置，不删除源文件。

脚本需要先阅读，并输入自己的实际端口或项目路径。
不会自动安装软件、切换节点、付款、清理或重建账号。
PowerShell 策略阻止脚本时，使用文章中已展开的手动命令，无需降低执行策略。

备份可能包含登录凭据，只在自己控制的存储中保管，不公开分享。
网络检测成功只代表当时连通，不能保证账号不会受到限制。

验证：3 个脚本语法解析通过；启动器和备份器在隔离测试目录中完成行为验证。
没有使用你的实际账号、订阅、代理或 Claude 配置做登录测试。
